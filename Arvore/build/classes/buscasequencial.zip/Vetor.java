/**
 * @(#)Vetor.java
 *
 *
 * @author 
 * @version 1.00 2010/2/11
 */

import java.util.Scanner;
public class Vetor
{
   
    int vet[] = new int[10];
    int tl=0;
    public Vetor()
    {}
    
    public void le_vetor()
    {
		Scanner n = new Scanner(System.in);
                System.out.println("Digite um numero");
		vet[tl]= n.nextInt();
		while(vet[tl]!= 0 && tl<10)
                {
		    tl++;
                    System.out.println("Digite um numero");
                    vet[tl]= n.nextInt();
                }
    }
    
    public int busca_exaustiva (int chave)
    {
		int i=0;
		while(i<tl && vet[i]!=chave)
		   i++;
		if(i<tl)
		  return i;
		return 0;
     }
    
    public int busca_exaustiva_sentinela (int chave)
    {
		int i=0;
                vet[tl]=chave;
		while(vet[i]!=chave)
		   i++;
		if(i<tl)
		  return i;
		return 0;
     }

     public void executa ()
     {
         le_vetor();
         Scanner n = new Scanner(System.in);
         System.out.println("Digite um numero");
         int num = n.nextInt();
         num = busca_exaustiva(num);
         if(num == 1)
            System.out.println("Achou");
         else
            System.out.println("N�o encontrado");
     }
}