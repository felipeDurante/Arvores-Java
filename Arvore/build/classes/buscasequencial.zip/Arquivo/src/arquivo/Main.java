package arquivo;

public class Main
{
   public static void main(String args[])
  {
    Arquivo_Java a = new Arquivo_Java("c:\\arq.dat");
    a.executa();
  }
}
