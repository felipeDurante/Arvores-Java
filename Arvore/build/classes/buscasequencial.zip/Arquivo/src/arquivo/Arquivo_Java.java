/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package arquivo;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author aluno
 */
public class Arquivo_Java
{
     private String nomearquivo;
  private RandomAccessFile arquivo;

  public Arquivo_Java(String nomearquivo)
  {
    this.nomearquivo = nomearquivo;
    try
    {
      arquivo = new RandomAccessFile(this.nomearquivo,"rw");
    }
    catch(IOException e){}
  }

  public void truncate(long pos) //desloca eof
  {
    try
    {
      arquivo.setLength(pos*Registro.length());
    }
    catch(IOException exc) { }
  }

  //igual ao eof do Pascal
  public boolean eof()      //se o ponteiro esta no eof
  {
    boolean retorno = false;
    try
    {
      if (arquivo.getFilePointer()==arquivo.length())  //retorna posicao em bytes
        retorno = true;                                //entao div por tam reg(52)
    }
    catch(IOException e){}
    finally
    {
      return(retorno);
    }
  }

  //insere um Registro no final do arquivo, passado por parâmetro
  public void inserirRegNoFinal(Registro reg)
  {
    try
    {
      arquivo.seek(arquivo.length());//ultimo byte
      reg.gravaNoArq(arquivo);
    }
    catch(IOException e){}
  }

  public void exibirArq()
  {
    int i;
    Registro aux = new Registro();
    try
    {
      arquivo.seek(0);
	  i=0;
	  while(!this.eof())
	  {
	     System.out.println("Posicao " + i);
		 aux.leDoArq(arquivo);
		 aux.exibirReg();
		 i++;
	  }
	}
	catch(IOException e){}
  }

  public void exibirUmRegistro(int pos)
  {
    Registro aux = new Registro();
    try
    {
      arquivo.seek(pos*Registro.length());
      System.out.println("Posicao " + pos);
      aux.leDoArq(arquivo);
	  aux.exibirReg();
	}
	catch(IOException e){}
  }

  public void seekArq(int pos)
  {
    try
    {
      arquivo.seek(pos*Registro.length());
	}
	catch(IOException e){}
  }

  public void leArq()
  {
    int codigo,idade;
    String nome;

    codigo=Entrada.leInteger("Digite o código");
    while (codigo!=0)
    {
      nome=Entrada.leString("Digite o nome");
      idade=Entrada.leInteger("Digite a idade");
      inserirRegNoFinal(new Registro(codigo,nome,idade));
      codigo=Entrada.leInteger("Digite o código");
    }
  }

  //.............................................................................
  /*

   insira aqui os métodos do MergeSort;

  */


  public void executa()
  {
    leArq();
    exibirArq();
  }
}
