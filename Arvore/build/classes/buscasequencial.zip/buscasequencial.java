
public class buscasequencial {

    int vet[]= new int[10],tl=0;

    public buscasequencial()
    {
    }

    public int busca_sequencial (int chave)
    {
        int pos=0;
        while(pos<tl && vet[pos]<chave)
	   pos++;
        if(pos<tl && vet[pos]==chave)
            return pos;
         return pos+tl;
    }

    public int busca_binaria (int chave)
    {
        int inicio,fim,meio;
        inicio =0;
        fim = tl-1;
        meio = fim/2;
        while(inicio<fim && vet[meio]!=chave)
        {
            if(vet[meio]>chave)
                fim=meio;
            if (vet[meio]<chave)
                inicio=meio+1;
            meio=(inicio+fim)/2;
        }
        if(vet[meio]==chave)
            return meio;
        else if(chave>vet[meio])
        return meio+1;
    }
}