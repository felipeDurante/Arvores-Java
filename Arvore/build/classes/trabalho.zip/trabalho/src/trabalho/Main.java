

package trabalho;

public class Main {


    public static String arruma(int n)
    {
		String s = n+"";
        while(s.length()>6)
            n=n/10;
		s= n+"";        
        String a = "";
        for(int i=0;i<6-s.length();i++)
            a += " ";
        return a+=n+"";
    }

    public static String arruma(float n)
	{
		String s = n+"";
        while(s.length()>6)
            n=n/10;
		s= n+"";        
        String a = "";
        for(int i=0;i<6-s.length();i++)
            a += " ";
        return a+=n+"";
    }

    public static void main(String[] args)
    {
        arquivo arqOrd, arqRev, arqRand, auxRev, auxRand,Tabela;
        arqOrd= new arquivo("C:\\ArqOrd.txt");
        arqRev= new arquivo("C:\\ArqRev.txt");
        arqRand = new arquivo("C:\\ArqRand.txt");
        auxRev= new arquivo("C:\\AuxArqRev.txt");
        auxRand= new arquivo("C:\\AuxArqRand.txt");
        Tabela = new arquivo("C:\\Tabela.txt");
        int t = 64,compO,movO,compRa,movRa,compRv,movRv,eMovO,eMovRa,eMovRv,eCompO,eCompRv,eCompRa;
        long tini,tfim,totOF,totRv,totRa,totalO,totalRv,totalRa,tempoT=0;
        arqOrd.geraArquivoOrdenado(t);
        arqRev.geraArquivoReverso(t);
        arqRand.geraArquivoRandomico(t);
        Tabela.gravar("|Metodos de Ordenação  |         Arquivo Ordenado         |      Arquivo em Ordem Reversa    |          Arquivo Randômico       |");
        Tabela.gravar("|                      | Comp.| Comp | Mov. | Mov. | Tempo| Comp.| Comp | Mov. | Mov. | Tempo| Comp.| Comp | Mov. | Mov. | Tempo|");
        Tabela.gravar("|                      | Prog | Equa | Prog | Equa |      | Prog | Equa | Prog | Equa |      | Prog | Equa | Prog | Equa |      |");
        Tabela.gravar("|----------------------|------|------|------|------|------|------|------|------|------|------|------|------|------|------|------|");

                //merge
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.merge();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (totOF/1000);
            System.out.println("Ordenado Merge");
            eMovO=0;
            eCompO=0;
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.merge();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Merge");
            totRv=(tfim-tini);
            totalRv= (totRv/1000);
            eCompO=0;
            eMovRv=0;
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.merge();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(totRa/1000);
            eCompO=0;
            eMovRa=0;
            System.out.println("Randomico Merge");
            tempoT+=totalRa;
            Tabela.gravar("|Merge                 |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(0)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(0)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
        //... Insercao Direta ...
         //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.insercao_direta();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (totOF/1000);
            System.out.println("Ordenado ID");
            eMovO=arqOrd.IdOrdMov(movO);
            eCompO=arqOrd.IdOrdComp(compO);
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.insercao_direta();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso ID");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompRv=auxRev.IdRevComp(compRv);
            eMovRv=auxRev.IdReveMov(movRv);
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.insercao_direta();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompRa=auxRand.IdRandComp(compRa);
            eMovRa=auxRand.IdRandMov(movRa);
            tempoT+=totalRa;
            System.out.println("Randomico ID");
            Tabela.gravar("|Inserção Direta       |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");

            // Inserção Binaria
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.Insercao_Binaria();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado IB");
            eMovO=arqOrd.IbMovOrd(movO);
            eCompO=arqOrd.IbCompOrd(compO);
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.Insercao_Binaria();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso IB");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompRv=auxRev.IbCompRev(compRv);
            eMovRv=auxRev.IbMovRev(movRv);
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.Insercao_Binaria();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompRa=auxRand.IbCompRand(compRa);
            eMovRa=auxRand.IbMovRand(movRa);
            System.out.println("Randomico IB");
            tempoT+=totalRa;
            Tabela.gravar("|Inserção Binária      |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");

            // Bolha
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.bolha_arquivo();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado Bolha");
            eMovO=arqOrd.BoMovOrd(movO);
            eCompO=arqOrd.BoComp(compO);
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.bolha_arquivo();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Bolha");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompO=arqOrd.BoComp(compO);
            eMovRv=auxRev.BoMovRev(movRv);
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.bolha_arquivo();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompO=arqOrd.BoComp(compO);
            eMovRa=auxRand.BoMovRand(movRa);
            System.out.println("Randomico Bolha");
            tempoT+=totalRa;            
            Tabela.gravar("|Bolha                 |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
            // shake
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.shake();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado Shake");
            eMovO=arqOrd.BoMovOrd(movO);
            eCompO=arqOrd.BoComp(compO);
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.shake();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Shake");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompO=arqOrd.BoComp(compO);
            eMovRv=auxRev.BoMovRev(movRv);
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.shake();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompO=arqOrd.BoComp(compO);
            eMovRa=auxRand.BoMovRand(movRa);
            System.out.println("Randomico Shake");
            tempoT+=totalRa;

            Tabela.gravar("|Shake                 |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
            // quick
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.quick_sempivo(0,arqOrd.Filesize()-1);
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado Quick");
            eMovO=0;
            eCompO=0;
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.quick_sempivo(0,arqOrd.Filesize()-1);
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Quick");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompO=0;
            eMovRv=0;
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.quick_sempivo(0,arqOrd.Filesize()-1);
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompO=0;
            eMovRa=0;
            System.out.println("Randomico Quick");
            tempoT+=totalRa;
            Tabela.gravar("|Quick                 |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
            //shell
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.shell();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado Shell");
            eMovO=0;
            eCompO=0;
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.shell();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Shell");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompO=0;
            eMovRv=0;
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.shell();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompO=0;
            eMovRa=0;
            System.out.println("Randomico Shell");
            tempoT+=totalRa;
            Tabela.gravar("|Shell                 |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
            
           //seleção direta
            //Arquivo Ordenado
            arqOrd.initComp();
            arqOrd.initMov();
            tini=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            arqOrd.seleção_direta();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compO=arqOrd.getComp();
            movO=arqOrd.getMov();
            totOF=(tfim-tini);
            totalO= (int)(totOF/1000);
            System.out.println("Ordenado Seleção");
            eMovO=arqOrd.SdMovOrd(movO);
            eCompO=arqOrd.SdComp(compO);
            tempoT+=totalO;
         // Arquivo Reverso
            auxRev.copiaArquivo(arqRev.getFile(),t);
            auxRev.initComp();
            auxRev.initMov();
            tini=System.currentTimeMillis();
            auxRev.seleção_direta();
            tfim=System.currentTimeMillis(); //método para pegar a hora atual em milisegundos
            compRv=auxRev.getComp();
            movRv=auxRev.getMov();
            System.out.println("Reverso Seleção");
            totRv=(tfim-tini);
            totalRv= (int)(totRv/1000);
            eCompO=auxRev.SdComp(compRv);
            eMovRv=auxRev.SdMovRev(movRv);
            tempoT+=totalRv;
         // Arqivo Randomico
            auxRand.copiaArquivo(arqRand.getFile(), t);
            auxRand.initComp();
            auxRand.initMov();
            tini=System.currentTimeMillis();
            auxRand.seleção_direta();
            tfim=System.currentTimeMillis();
            compRa=auxRand.getComp();
            movRa=auxRand.getMov();
            totRa=(tfim-tini);
            totalRa=(int)(totRa/1000);
            eCompO=arqOrd.SdComp(compO);            
            eMovRa=auxRand.SdMovRad(movRa);
            tempoT+=totalRa;
            System.out.println("Randomico Seleção");            
            Tabela.gravar("|Seleção Direta        |"+arruma(compO)+"|"+arruma(eCompO)+"|"+arruma(movO)+"|"+arruma(eMovO)+"|"+arruma(totalO)+"|"+arruma(compRv)+"|"+arruma(eCompRv)+"|"+arruma(movRv)+"|"+arruma(eMovRv)+"|"+arruma(totalRv)+"|"+arruma(compRa)+"|"+arruma(eCompRa)+"|"+arruma(movRa)+"|"+arruma(eMovRa)+"|"+arruma(totalRa)+"|");
            Tabela.gravar("---------------------------------------------------------------------------------------------------------------------------------");
            Tabela.gravar("Total  -->"+tempoT);

    }

}
