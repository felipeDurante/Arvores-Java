

package trabalho;


import java.io.IOException;
import java.io.RandomAccessFile;


public class arquivo
{
    private String nomearquivo;
    private RandomAccessFile arquivo;
    private int comp, mov;



    public arquivo(String nome)
    {
        this.nomearquivo = nome;

        try {
            arquivo = new RandomAccessFile(this.nomearquivo, "rw");
        } catch (IOException e) {}
    }

    public arquivo ()
    {}

    public void inserenofinal(registro reg)
      {
        try
        {
          arquivo.seek(this.arquivo.length());//ultimo byte
          reg.gravaNoArq(this.arquivo);
        }
        catch(IOException e){}
      }

    public void exibirArq()
  {
    int i;
    registro aux = new registro();
    try
    {
      arquivo.seek(0);
	  i=0;
	  while(!this.eof())
	  {
	     System.out.println("Posicao " + i);
		 aux.leDoArq(arquivo);
		 aux.exibirReg();
		 i++;
	  }
	}
	catch(IOException e){}
  }

    public void gravar(String linha)
    {
        try{

            arquivo.writeBytes(linha);
            arquivo.writeBytes(System.getProperty("line.separator"));
        }
        catch(IOException e){}
    }

    public void copiaArquivo(RandomAccessFile arq,int tl)
    {
        registro aux = new registro();
        int i=0;
        try
        {
            arq.seek(0);
            arquivo.seek(0);
            aux.leDoArq(arq);
            while(i<tl)
            {
                aux.gravaNoArq(arquivo);
                aux.leDoArq(arq);
                i++;
            }
        }
        catch(IOException e){}
    }

    public RandomAccessFile getFile()
    {
        return arquivo;
    }

    public void initComp()
    {
           comp =0;
    }

    public void initMov()
    {
           mov =0;
    }

    public int getComp()
    {
        return comp;
    }

    public int getMov()
    {
        return mov;
    }

    public int IdOrdMov (int n)
    {
        int conta=3*(n-1);
        return conta;
    }

    public int IdRandMov (int n)
    {
        int num =(int) Math.sqrt(n), conta;
        conta =((num+(9*n)-10)/4);
        return conta;
    }

    public int IdReveMov (int n)
    {
        int conta,num=(int) Math.sqrt(n);
        return conta=((num+(3*n)-4)/2);
    }

    public int IdOrdComp (int n)
    {
        int conta;
        return conta=n-1;
    }

    public int IdRandComp (int n)
    {
        int num=(int) Math.sqrt(n),conta;
        return conta=((num+n-2)/4);
    }

    public int IdRevComp (int n)
    {
        int num=(int) Math.sqrt(n),conta;
        return conta=((num+n-4)/4);
    }

    public int SdComp (int n)
    {
        int nComp = ( ((n*n)-n) /2);
        return nComp;
    }

    public int SdMovOrd(int n)
    {
        int nMov = 3 * (n -1);
        return nMov;
    }

    public int SdMovRev(int n)
    {
        int nMov = ( (n*(2/4)) + (3*(n-1)) );
        return nMov;
    }
    public int SdMovRad(int n)
    {
        int nMov = (int)( n*(Math.log(n) + 0.577216) );
        return nMov;
    }

    public int BoComp(int n)
    {
        int nComp = ( ((n*n)-n) /2);
        return nComp;
    }

    public int BoMovOrd (int n)
    {
        return 0;
    }

    public int BoMovRev (int n)
    {
        int nMov = 3*( ((n*n) -n) /4);
       return nMov;
    }

    public int BoMovRand (int n)
    {
        int nMov = 3*( ((n*n) -n) /2);
        return nMov;
    }

    public int IbMovOrd(int n)
    {
        int nMov = 3 * (n -1);
        return nMov;
    }

    public int IbMovRand(int n)
    {
        int nMov = ( (n*n) + (9*n) - 10 ) / 4;
        return nMov;
    }

    public int IbMovRev(int n)
    {
        int nMov = ( (n*n) + (3*n) - 4 ) / 2;
        return nMov;
    }

    public int IbCompOrd (int n)
    {
        int nComp = (int)(n* (Math.log10(n) - Math.log(n) + 0.5) );
        return nComp;
    }

    public int IbCompRev (int n)
    {
        int nComp = (int)(n* (Math.log10(n) - Math.log(n) + 0.5) );
        return nComp;
    }

    public int IbCompRand (int n)
    {
        int nComp = (int)(n* (Math.log10(n) - Math.log(n) + 0.5) );
    return nComp;
    }
    public int Filesize()
    {
        int ret=0;
        try
        {
        ret = (int)arquivo.length()/registro.length();
        }
        catch(IOException e){}
        return ret;
    }

    public void seekArq(int pos)
    {
        try
        {
          arquivo.seek(pos*registro.length());
            }
	catch(IOException e){}
    }

    public boolean eof() {
        boolean retorno = false;

        try {
            if ( arquivo.getFilePointer() == arquivo.length() ) {
                retorno = true;
            }
        } catch (IOException e) {
        } finally {
            return (retorno);
        }
    }

    public void truncate(long pos) {
        try {
            arquivo.setLength(pos * registro.length());
        } catch (IOException exc) {}
    }

    public void geraArquivoOrdenado(int total)
    {
        for(int i=0;i<total;i++)
            inserenofinal(new registro(i));
    }

    public void geraArquivoReverso(int total)
    {
        for(int i=total-1;i>=0;i--)
            inserenofinal(new registro(i));
    }

    public void geraArquivoRandomico(int total)
    {
         int num;
          for(int i=0;i<total;i++)
         {
             num = (int) (total*Math.random());
             inserenofinal(new registro(num));
         }
    }

    // Ordenações

    public void Insercao_Binaria()
   {
       registro aux = new registro();
       registro aux2 = new registro();
       int pos, i;
       for (i = 1; i < Filesize(); i++)
       {
           seekArq(i);
           aux.leDoArq(arquivo);
           pos = busca_binaria(aux.getCodigo(), i);
           if (pos >= i)
               pos = pos - i;
           for (int j = i; j > pos; j--)
           {
               seekArq(j - 1);
               aux2.leDoArq(arquivo);
               seekArq(j); aux2.gravaNoArq(arquivo);
               mov++;
           }
           seekArq(pos);
           aux.gravaNoArq(arquivo);
           mov++;
       }
   }

    public int busca_binaria(int chave, int TL)
    {
        int inicio = 0, fim = TL - 1, meio = (inicio + fim) / 2;
        registro aux = new registro();
        seekArq(meio);
        aux.leDoArq(arquivo);
        comp++;
        while (inicio < fim && aux.getCodigo() != chave)
        {
            comp++;
            if (chave > aux.getCodigo())
                inicio = meio + 1;
            else
                fim = meio - 1;
            meio = (inicio + fim) / 2;
            seekArq(meio);
            aux.leDoArq(arquivo); comp++;
        }
        comp++;
        if (aux.getCodigo() == chave)
            return meio;
        comp++;
        if (chave > aux.getCodigo())
            return meio + TL + 1;
        return meio + TL;
    }

  public void insercao_direta()
  {
      registro aux= new registro();
      registro aux2= new registro();
      int pos,i,tl=Filesize();
      for(i=1;i<tl;i++)
      {
          pos=i;
          seekArq(pos);
          aux.leDoArq(arquivo);
          seekArq(pos-1);
          aux2.leDoArq(arquivo);
          while(pos>0 && aux2.getCodigo() >aux.getCodigo() )
          {
              comp+=2;
              seekArq(pos);
              aux2.gravaNoArq(arquivo);
              mov++;
              pos--;
              if(pos!=0)
              {
                  seekArq(pos-1);
                  aux2.leDoArq(arquivo);
              }
              comp++;
          }
          comp++;
          seekArq(pos);
          aux.gravaNoArq(arquivo);
          mov++;
      }
  }

  public void bolha_arquivo()
  {
      int tl2= Filesize();
      registro reg1= new registro();
      registro reg2= new registro();
      while(tl2>1)
      {
          comp++;
          for(int i=0;i<tl2-1;i++)
          {
              comp++;
              seekArq(i);
              reg1.leDoArq(arquivo);
              seekArq(i+1);
              reg2.leDoArq(arquivo);
              if(reg1.getCodigo()>reg2.getCodigo())
              {
                seekArq(i);
                reg2.gravaNoArq(arquivo);
                seekArq(i+1);
                reg1.gravaNoArq(arquivo);
                mov++;
              }
              comp++;
          }

          tl2--;
      }
      comp++;
  }

   public void seleção_direta()
  {
      int i,j,posmenor,tl=Filesize();
      registro menor= new registro();
      registro reg1= new registro();
      for(i=0;i<tl-1;i++)
      {
          comp++;
          seekArq(i);
          menor.leDoArq(arquivo);
          posmenor=i;
          for(j=i+1;j<tl;j++)
          {
              comp++;
              seekArq(j);
              reg1.leDoArq(arquivo);
              if(reg1.getCodigo()<menor.getCodigo())
              {
                 seekArq(j);
                 menor.leDoArq(arquivo);
                 posmenor=j;
              }
              comp++;
          }
          seekArq(i);
          reg1.leDoArq(arquivo);
          seekArq(posmenor);
          reg1.gravaNoArq(arquivo);
          seekArq(i);
          menor.gravaNoArq(arquivo);
          mov++;
      }
  }
   public void heap()
  {
      int npai,f1,f2,i=Filesize(),maior;
      registro aux1 = new registro();
      registro aux2 = new registro();
      while(i>1)
      {
          comp++;
          for(npai = i/2 - 1;npai>-1;npai --)
          {
              comp++;
              maior =f1 = npai + npai + 1;
              f2= f1 +1;
              seekArq(f1);
              aux1.leDoArq(arquivo);
              aux2.leDoArq(arquivo);
              comp++;
              if(f2<i && aux2.getCodigo()>aux1.getCodigo())
                  maior = f2;
              seekArq(maior);
              aux1.leDoArq(arquivo);
              seekArq(npai);
              aux2.leDoArq(arquivo);
              comp++;
              if(aux2.getCodigo()<aux1.getCodigo())
              {
                  seekArq(maior);
                  aux2.gravaNoArq(arquivo);
                  seekArq(npai);
                  aux1.gravaNoArq(arquivo);mov++;

              }
          }
          seekArq(0);
          aux1.leDoArq(arquivo);
          seekArq(i-1);
          aux2.leDoArq(arquivo);
          seekArq(0);
          aux2.gravaNoArq(arquivo);
          seekArq(i-1);
          aux1.gravaNoArq(arquivo);mov++;

          i--;
      }

  }



    public void quick_sempivo(int ini,int fim)
    {
        int aux;
        int i=ini,j=fim;
        registro reg= new registro();
        registro reg2= new registro();
        while(i<j)
        {
            seekArq(j);comp++;
            reg2.leDoArq(arquivo);
            seekArq(i);
            reg.leDoArq(arquivo);
            while(i<j && reg.getCodigo()<=reg2.getCodigo())
            {
                comp+=2; i++;
                seekArq(i);
                reg.leDoArq(arquivo);
            }comp++;
            if(i<j)
            {
                seekArq(j);
                reg2.leDoArq(arquivo);
                seekArq(i);
                reg.leDoArq(arquivo);
                seekArq(j);
                reg.gravaNoArq(arquivo);mov++;
                seekArq(i);
                reg2.gravaNoArq(arquivo);mov++;
            }comp++;
            seekArq(j);
            reg2.leDoArq(arquivo);
            seekArq(i);
            reg.leDoArq(arquivo);
            while(i<j && reg2.getCodigo()>=reg.getCodigo())
            {
                j--;comp+=2;
                seekArq(j);
                reg2.leDoArq(arquivo);
            }comp++;
            if(i<j)
            {
                seekArq(j);
                reg2.leDoArq(arquivo);
                seekArq(i);
                reg.leDoArq(arquivo);
                seekArq(j);
                reg.gravaNoArq(arquivo);
                seekArq(i);
                reg2.gravaNoArq(arquivo);mov++;
            }comp++;
        }comp++;
        if(0<i-1)
            quick_sempivo(0,i-1);comp++;
        if(j+1<fim)
            quick_sempivo(j+1,fim);comp++;
    }


   public void shell()
   {
        int j=0,dist=4,i,k=0;
        registro aux1 = new registro(),aux2= new registro();
        while(dist>0)
        {
            i=0;comp++;
            while(i<dist)
            {
                 j=i;comp++;
                 while(j+dist<Filesize())
                 {
                    seekArq(j);comp++;
                    aux1.leDoArq(arquivo);
                    seekArq(j+dist);
                    aux2.leDoArq(arquivo);
                    comp++;
                    if(aux1.getCodigo()> aux2.getCodigo())
                    {
                        seekArq(j);
                        aux2.gravaNoArq(arquivo);
                        seekArq(j+dist);
                        aux1.gravaNoArq(arquivo);
                        k=j;mov++;
                        if(k-dist>=0)
                        {
                            seekArq(k-dist);
                            aux2.leDoArq(arquivo);
                            seekArq(k);
                            aux1.leDoArq(arquivo);

                            while(k-dist>=0 && aux1.getCodigo()<aux2.getCodigo())
                            {
                                 seekArq(k-dist);
                                 aux1.gravaNoArq(arquivo);
                                 seekArq(j);mov++;
                                 aux2.gravaNoArq(arquivo);
                                 k-=dist;
                                 comp++;
                                 if(k-dist>=0)
                                 {
                                    seekArq(k-dist);
                                    aux2.leDoArq(arquivo);
                                    seekArq(k);
                                    aux1.leDoArq(arquivo);

                                 }
                            }
                        }
                   }
                   j+=dist;
                }
                 i++;
        }
        dist=dist/2;
      }
 }


 void shake ()
   {
       int fim=Filesize()-1, inicio=0;
       registro aux= new registro();
       registro aux2= new registro();

       while(inicio < fim)
       {
           comp++;
	   for(int i=inicio;i<fim;i++)
           {
               seekArq(i);comp++;
               aux.leDoArq(arquivo);
               seekArq(i+1);
               aux2.leDoArq(arquivo);
               if (aux.getCodigo()>aux2.getCodigo())
               {
                   seekArq(i);
                   aux.leDoArq(arquivo);
                   seekArq(i+1);
                   aux2.leDoArq(arquivo);
                   seekArq(i);
                   aux2.gravaNoArq(arquivo);
                   seekArq(i+1);
                   aux.gravaNoArq(arquivo);mov++;
               }comp++;
           }
           fim--;
           for (int i=fim;i>inicio;i--)
           {
               seekArq(i);comp++;
               aux.leDoArq(arquivo);
               seekArq(i-1);
               aux2.leDoArq(arquivo);
               if (aux.getCodigo()<aux2.getCodigo())
               {
                   seekArq(i);
                   aux.leDoArq(arquivo);
                   seekArq(i-1);
                   aux2.leDoArq(arquivo);
                   seekArq(i);
                   aux2.gravaNoArq(arquivo);
                   seekArq(i-1);
                   aux.gravaNoArq(arquivo);mov++;
               }comp++;
           }
           inicio++;
       }comp++;
   }

  private void particao(registro[] vet1, registro[] vet2)
    {
        int i=0,met=Filesize()/2;
        while(i<met)
        {
            seekArq(i);
            vet1[i]=new registro();
            vet1[i].leDoArq(arquivo);
            seekArq(i+met);
            vet2[i]=new registro();
            vet2[i++].leDoArq(arquivo);

        }
    }

   private void fusao(registro[] vet1, registro[] vet2, int seq)
    {
        int i=0,j=0,k=0;
        int tseq=seq;
        comp++;
        while(k<Filesize())
        {
            comp++;
            while(i<seq && j<seq)
            {
               comp++;
               if(vet1[i].getCodigo()<vet2[j].getCodigo())
               {
                seekArq(k++);
                vet1[i++].gravaNoArq(arquivo);
                mov++;
               }
               else
               {
                seekArq(k++);
                vet2[j++].gravaNoArq(arquivo);
                mov++;
               }
               comp++;
            }

            while(i<seq)
            {
                seekArq(k++);
                vet1[i++].gravaNoArq(arquivo); comp++;
                mov++;
            }
            while(j<seq)
            {
                seekArq(k++);
                vet2[j++].gravaNoArq(arquivo); comp++;
                mov++;
            }
            seq+=tseq;
         comp++;
        }

    }

    public void merge()
   {
        registro vet1[] = new registro[Filesize()/2];
        registro vet2[] = new registro[Filesize()/2];
        int seq=1;
        comp++;
        while(seq<Filesize())
        {
            particao(vet1,vet2);
            fusao(vet1,vet2,seq);
            seq*=2;
            comp++;
        }
   }
}