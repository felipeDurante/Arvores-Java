package animacao;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import java.awt.Dimension;
import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Locale;

public class Animacao extends JFrame
{
  private JButton vet[];
  private JPanel Panel;
  private JButton jB_animacao;
  private JButton jB_gerar;
  private JButton jB_shell;
  private JTextField jTF_quant;

  public Animacao(int width, int height)
  {
    setTitle("Exemplo de Animação");
    vet = new JButton[15];
    init(width, height);
  }
  private void init(int width, int height)
  {
    setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
    getContentPane().setLayout(null);

    Panel = new JPanel();
    Panel.setBounds(0,0,width, height);
    Panel.setLayout(null);
    getContentPane().add(Panel);

    jTF_quant = new JTextField();
    jTF_quant.setBounds(10, 530, 60, 20);
    jTF_quant.setText("0");
    Panel.add(jTF_quant);

    jB_gerar = new JButton();
    jB_gerar.setText("Gerar");
    jB_gerar.setBounds(80, 530, 90, 23);
    Panel.add(jB_gerar);
    jB_gerar.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                jB_gerarActionPerformed(evt);
            }
        });

    jB_animacao = new JButton();
    jB_animacao.setText("Inserção Binaria");
    jB_animacao.setBounds(180, 530, 120, 23);
    Panel.add(jB_animacao);
    jB_animacao.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                //jB_animacaoActionPerformed(evt);
                //animacao_bolha(evt);
                insercao_binaria(evt);
            }
        });

    jB_shell = new JButton();
    jB_shell.setText("Shell");
    jB_shell.setBounds(310, 530, 120, 23);
    Panel.add(jB_shell);
    jB_shell.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evt) {
                  shell(evt);
            }
         });
  }

  private void jB_gerarActionPerformed(ActionEvent evt)
  {
    int x=15;
    for (int i=0; i<15; i++)
    {
      if (vet[i]!=null)
      {
        Panel.remove(vet[i]);
        vet[i]=null;
      }
    }
    String aux = jTF_quant.getText().trim();
    if (!aux.equals("") && Integer.parseInt(aux)<=15)
    {
      for (int i=0 ; i<Integer.parseInt(aux) ; i++)
      {
        vet[i]=new JButton();
        vet[i].setBounds(x,150,50,50);
        vet[i].setVisible(true);
        vet[i].setBackground(new Color(255,255,255));
        vet[i].setText(String.valueOf(Math.round(Math.random()*100)));
        Panel.add(vet[i]);
        Panel.setVisible(true);
        x=x+51;
      }
      repaint();
    }
    else
      JOptionPane.showMessageDialog(null,"Digite uma quantidade maior que 0 e menor ou igual a 15!");
  }

   private void jB_animacaoActionPerformed(ActionEvent evt)
  {
    for (int i=0 ; i<15 ; i++)
    if (vet[i]!=null)
    {
      vet[i].setLocation(vet[i].getX()+50, vet[i].getY()+50);
      for (int j=0 ; j<50 ; j++)
      {
        vet[i].setLocation(vet[i].getX()+1, vet[i].getY()-1);

        try {
          Thread.sleep(10);
      
        } catch (InterruptedException f) {}

        Panel.paintImmediately(Panel.getBounds());
      }
    }
  }
  
  private void animacao_bolha (ActionEvent evt)
  {
    String aux = jTF_quant.getText().trim();
    JButton a;
    int tl =Integer.parseInt(aux),tl2=tl;
    for (int k=0 ; k<15 ; k++)
    if (vet[k]!=null)
    {   
          while(tl2>1)
          {
              for(int i=0;i<tl2-1;i++)
              {
                  if(Integer.parseInt(vet[i].getText())>Integer.parseInt(vet[i+1].getText()))
                  {
                       a= vet[i];
                       vet[i]=vet[i+1];
                       vet[i+1]=a;
                       int x1=vet[i].getX(),x2=vet[i+1].getX(),y1=vet[i].getY(),y2=vet[i+1].getY();
                       vet[i].setBackground(new Color(255,0,0));
                       vet[i+1].setBackground(new Color(255,0,0));
                       vet[i].setLocation(vet[i].getX(), vet[i].getY()+50);
                       vet[i+1].setLocation(vet[i+1].getX(), vet[i+1].getY()-50);
                       for (int j=0 ; j<43 ; j++)
                       {
                            vet[i].setLocation(vet[i].getX()-1, vet[i].getY());
                            vet[i+1].setLocation(vet[i+1].getX()+1, vet[i+1].getY());
                            try {
                              Thread.sleep(20);
                            } catch (InterruptedException f) {}

                            Panel.paintImmediately(Panel.getBounds());
                       }
                       vet[i].setLocation(x2,y2);
                       vet[i+1].setLocation(x1,y1);
                       vet[i].setBackground(new Color(255,255,255));
                       vet[i+1].setBackground(new Color(255,255,255));
                  }
              }
              tl2--;
             Panel.paintImmediately(Panel.getBounds());
          }
      }
    }

  private int busca_binaria(int chave,int tl)
  {
        int inicio,fim,meio;
        inicio =0;
        fim = tl-1;
        meio = fim/2;
        int aux=Integer.parseInt(vet[meio].getText());
        //Integer.parseInt(vet[i].getText()
        while(inicio<fim && aux!=chave)
        {
            if(aux>chave)
                fim=meio;
            if (aux<chave)
                inicio=meio+1;
            meio=(inicio+fim)/2;
            aux=Integer.parseInt(vet[meio].getText());
        }
        if(aux==chave)
            return meio;
        if(chave>aux)
          return meio+tl+1;
        return meio+tl;
  }

  private void insercao_binaria(ActionEvent evt)
  {        
        JButton a;
        int tl =Integer.parseInt(jTF_quant.getText().trim());
        int aux1,pos,k=0;
        int x1,x2,y1,y2;
      
            for(int i=1;i<tl;i++)
            {
                aux1=Integer.parseInt(vet[i].getText());
                a=vet[i];
                pos=busca_binaria(aux1,i);
                if(pos>=i)
                    pos=pos-i;

                x1=vet[i].getX();
                x2=vet[pos].getX();
                y2=vet[pos].getY();
                
                pisca(i); 
                vet[i].setBackground(new Color(0,0,255));
                vet[i].setLocation(vet[i].getX(), vet[i].getY()-50);             
             
             for(int l=i-1;l>=pos;l--)
             {
                for(int y=0;y<51;y++)
                 {
                      vet[l].setLocation(vet[l].getX()+1, vet[l].getY());
                      try {
                           Thread.sleep(10);
                      } catch (InterruptedException f) {}
                       Panel.paintImmediately(Panel.getBounds());                

                }
             }
                while(x1>x2)
                {
                      vet[i].setLocation(vet[i].getX()-1, vet[i].getY());
                      try {
                           Thread.sleep(10);
                      } catch (InterruptedException f) {}
                       Panel.paintImmediately(Panel.getBounds());
                      x1--;
                }
              
                
                vet[i].setLocation(x2,y2);
                pisca(i);
                vet[i].setBackground(new Color(255,255,255));
                for(int j=i;j>pos;j--)
    			vet[j]=vet[j-1];
                 vet[pos]=a;
                 

            
                  Panel.paintImmediately(Panel.getBounds());
            }

  }

  public void troca (int a, int b)
  {
      vet[a].setLocation(vet[a].getX(), vet[a].getY()+50);
      vet[b].setLocation(vet[b].getX(), vet[b].getY()-50);
      int aux=vet[a].getX();
      int aux2=vet[b].getX();      
      while (aux<aux2)
      {
          vet[a].setLocation(vet[a].getX()+1, vet[a].getY());
          vet[b].setLocation(vet[b].getX()-1, vet[b].getY());
          try {
               Thread.sleep(10);
          } catch (InterruptedException f) {}
          Panel.paintImmediately(Panel.getBounds());
          aux++;
      }   
  }

  public void pisca (int a)
  {
      for (int g=0;g<3;g++)
      {
          for (int h=1; h<10; h++)
          {
            vet[a].setBackground(new Color(0,0,255));
            
            try {
               Thread.sleep(10);
          } catch (InterruptedException f) {}
            Panel.paintImmediately(Panel.getBounds());
          }
          for (int h=1; h<10; h++)
          {
            vet[a].setBackground(new Color(255,0,0));
           
            try {
               Thread.sleep(10);
          } catch (InterruptedException f) {}
            Panel.paintImmediately(Panel.getBounds());
          }
      }
  }

 private void shell(ActionEvent evt)
   {            
       String aux = jTF_quant.getText().trim();
       JButton a = null;
       int tl = Integer.parseInt(aux);
       int i=0,k,j,dist = 4;
       int x1,x2,y1,y2;
       while(dist>0)
       {
           i=0;
           while(i<dist)
           {
               j=i;
               while (j+dist<tl)
               {
                   if(Integer.parseInt(vet[j].getText()) > Integer.parseInt(vet[j+dist].getText()))
                   {
                         a=vet[j+dist];
                         vet[j+dist]=vet[j];
                         vet[j]=a;
                         k=j;

                         x1=vet[j+dist].getX(); y1=vet[j+dist].getY();
                         x2=vet[j].getX(); y2=vet[j].getY();
                         pisca(j+dist);
                         pisca(j);
                         vet[j+dist].setBackground(new Color(0,0,255));
                         vet[j].setBackground(new Color(0,0,255));
                         
                         troca(j+dist,j);

                         pisca(j+dist);
                         pisca(j);

                         vet[j+dist].setLocation(x2, y2);
                         vet[j].setLocation(x1, y1);
                         vet[j+dist].setBackground(new Color(255,255,255));
                         vet[j].setBackground(new Color(255,255,255));
                         while (k-dist>=0 && Integer.parseInt(vet[k].getText())< Integer.parseInt(vet[k-dist].getText()))
                         {                         
                                 a=vet[k];
                                 vet[k]=vet[k-dist];
                                 vet[k-dist]=a;                                

                                 x1=vet[k].getX(); y1=vet[k].getY();
                                 x2=vet[k-dist].getX(); y2=vet[k-dist].getY();
                                 pisca(k);
                                 pisca(k-dist);
                                 vet[k].setBackground(new Color(0,0,255));
                                 vet[k-dist].setBackground(new Color(0,0,255));
                                 
                                 troca(k,k-dist);
                                 pisca(k);
                                 pisca(k-dist);
                                 
                                 vet[k].setLocation(x2, y2);
                                 vet[k-dist].setLocation(x1, y1);                         
                                 vet[k].setBackground(new Color(255,255,255));
                                 vet[k-dist].setBackground(new Color(255,255,255));
                                 k=k-dist;
                         }
                   }
                   j+=dist;
               }
               i++;
           }
           dist/=2;
     }
   }

  public static void main(String[] args)
  {
    int width=800;
    int height=600;
    JFrame.setDefaultLookAndFeelDecorated(true);
    Animacao janela = new Animacao(width,height);
    janela.setSize(new Dimension(width,height));
    janela.setResizable(false);
    janela.setVisible(true);
  }
}

