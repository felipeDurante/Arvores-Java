

package listaencadeada;

public class Lista
{
    private No inicio;
    private No fim;

    public Lista()
    {
        Inicializa();
    }

    public Lista (int i)
    {
        Inicializa();
        if(i==1)
            for(int j=0;j<15;j++)
              InsereLista_noFinal(j);
        if(i==2)
            for(int j=0;j<15;j++)
                InsereLista_tipoPilha(j);
        if(i==3)
            for(int j=0;j<15;j++)
                InsereLista_noFinal((int) Math.round(Math.random()*14+1));
    }

    public void Inicializa()
    {
        inicio=fim=null;
    }

    public void InsereLista_noFinal(int info)
    {
        No nova = new No(fim,null,info);
        if(inicio==null)
            inicio=fim= nova;
        else
        {
            fim.setProx(nova);
            fim= nova;
        }
    }

    public void InsereLista_tipoPilha(int info)
    {
        No nova = new No(null,inicio,info);
        if(inicio==null)
            inicio=fim=nova;
        else
        {
            inicio.setAnt(nova);
            inicio=nova;
        }
    }

    public void Exibe_Lista()
    {
        No aux = inicio;
        while(aux!=null)
        {
            System.out.print(aux.getInfo()+" ");
            aux= aux.getProx();
        }
    }

    public No Busca_Exaustiva(int Elem)
    {
        No aux = inicio;
        while(aux!=null && aux.getInfo()!=Elem)
            aux = aux.getProx();
        return aux;
    }

    public void RemoveLista(int info)
    {
         No aux = Busca_Exaustiva(info);
         if(aux!=null)
         {
             if(inicio==fim)
                 Inicializa();
             else if(inicio==aux)
             {
                 inicio = inicio.getProx();
                 inicio.setAnt(null);
             }
             else if(fim==aux)
             {
                 fim = fim.getAnt();
                 fim.setProx(null);
             }
             else
             {
                 aux.getAnt().setProx(aux.getProx());
                 aux.getProx().setAnt(aux.getAnt());
             }
         }         
    }

    public void Insecao_Direta()
   {
       int aux;
       No pos;
       for(No i=inicio.getProx();i!=null;i=i.getProx())
       {
          pos=i;
          aux=pos.getInfo();
          while(pos!=inicio && aux<pos.getAnt().getInfo())
          {
              pos.setInfo(pos.getAnt().getInfo());
              pos=pos.getAnt();
          }
          pos.setInfo(aux);
       }
   }

   public void Selecao_Direta()
   {
       int menor;

       No posmenor;
       for(No i=inicio;i!=null;i=i.getProx())
       {
           menor=i.getInfo();posmenor=i;
           for(No j=i.getProx();j!=null;j=j.getProx())
               if(j.getInfo()<menor)
               {
                   menor=j.getInfo();
                   posmenor=j;
               }
           posmenor.setInfo(i.getInfo());
           i.setInfo(menor);
       }
   }

    public No getFim() {
        return fim;
    }

    public No getInicio() {
        return inicio;
    }

   public void Shake()
   {
       No ini=inicio,fim2=fim,i;
       int aux;
       while(ini!=fim2)
       {
           i=ini;
           while(i!=fim2)
           {
               if(i.getInfo()>i.getProx().getInfo())
               {
                   aux=i.getInfo();
                   i.setInfo(i.getProx().getInfo());
                   i.getProx().setInfo(aux);
               }
               i=i.getProx();
           }
           fim2=fim2.getAnt();
           i=fim2;
           while(i!=ini)
           {
               if(i.getInfo()<i.getAnt().getInfo())
               {
                   aux=i.getInfo();
                   i.setInfo(i.getAnt().getInfo());
                   i.getAnt().setInfo(aux);
               }
               i=i.getAnt();
           }
           ini=ini.getProx();
       }
   }

    public void bolha ()
    {
        No fim2 = fim, i=inicio;
        int aux;
        while (fim2!=null)
        {
            i=inicio;
            while (i.getProx()!=null)
            {                
                if (i.getInfo()> i.getProx().getInfo())
                {
                    aux=i.getProx().getInfo();
                    i.getProx().setInfo(i.getInfo());
                    i.setInfo(aux);
                }
                i=i.getProx();
            }
            fim2=fim2.getAnt();
        }
    }
}
