
package listaencadeada;


public class Main
{

    

    public static void main(String[] args) 
    {
        Lista O=new Lista(1) ,Ra=new Lista(3),Rv=new Lista(2);

        O.Insecao_Direta();
        System.out.println("ID Ord");
        O.Selecao_Direta();
        System.out.println("SD Ord ");
        O.Shake();
        System.out.println("Shake Ord");
        O.bolha();
        System.out.println("Bolha Ord");
        Ra.Insecao_Direta();
        Ra=new Lista(3);
        Ra.Selecao_Direta();
        Ra=new Lista(3);
        Ra.Shake();
        Ra=new Lista(3);
        Ra.bolha();
        Rv.Insecao_Direta();
        Rv=new Lista(2);
        Rv.Selecao_Direta();
        Rv=new Lista(2);
        Rv.Shake();
        Rv=new Lista(2);
        Rv.bolha();
    }

}
