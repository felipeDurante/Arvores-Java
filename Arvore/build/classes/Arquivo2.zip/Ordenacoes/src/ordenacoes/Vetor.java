

package ordenacoes;

import java.util.Scanner;


public class Vetor
{
    int vet[] = new int[10];
    int tl=0;
    public Vetor()
    {}

    public void le_vetor()
    {
		Scanner n = new Scanner(System.in);
                System.out.println("Digite um numero");
		vet[tl]= n.nextInt();
		while(vet[tl]!= 0 && tl<10)
                {
		    tl++;
                    System.out.println("Digite um numero");
                    vet[tl]= n.nextInt();
                }
    }

    public int busca_exaustiva (int chave)
    {
		int i=0;
		while(i<tl && vet[i]!=chave)
		   i++;
		if(i<tl)
		  return i;
		return 0;
     }

    public int busca_exaustiva_sentinela (int chave)
    {
		int i=0;
                vet[tl]=chave;
		while(vet[i]!=chave)
		   i++;
		if(i<tl)
		  return i;
		return 0;
     }

    public int busca_sequencial (int chave)
    {
        int pos=0;
        while(pos<tl && vet[pos]<chave)
	   pos++;
        if(pos<tl && vet[pos]==chave)
            return pos;
         return pos+tl;
    }

    public int busca_binaria (int chave,int tl)
    {
        int inicio,fim,meio;
        inicio =0;
        fim = tl-1;
        meio = fim/2;
        while(inicio<fim && vet[meio]!=chave)
        {
            if(vet[meio]>chave)
                fim=meio;
            else
                inicio=meio+1;
            meio=(inicio+fim)/2;
        }
        if(vet[meio]==chave)
            return meio;
        else if(chave>vet[meio])
        return meio+tl+1;

        return meio+tl;
    }

    public void insercao_direta()
    {
        int aux,pos=0,i;
        for(i=1;i<tl;i++)
        {
            aux=vet[i];
            pos=i;
            while(pos>0 && vet[pos-1]>aux)
            {
                vet[pos]=vet[pos-1];
                pos--;
            }
            vet[pos]=aux;
        }
    }

    public void insercao_binaria()
    {
    	int aux,pos,i;
    	for(i=1;i<tl;i++)
    	{
		aux=vet[i];
    		pos= busca_binaria(aux,i);
    		if(pos>=i)
    			pos=pos-i;
    		for(int j=i;j>pos;j--)
    			vet[j]=vet[j-1];
    		vet[pos]=aux;
    	}
    }

    public void selecao_direta ()
    {
    	int i,j, menor, posmenor;
    	for (i=0;i<tl-1;i++)
    	{
    		menor=vet[i];
    		posmenor=i;
    		for(j=i+1;j<tl;j++)
    		{
    			if (vet[j]<menor)
    			{
    				menor=vet[j];
    				posmenor=j;
    			}
    		}
    		vet[posmenor]=vet[i];
    		vet[i]=menor;
    	}
    }

    public void bolha()
    {
    	int tl2=tl,aux;
    	while (tl2>1)
    	{
    		for (int i=0;i<tl2-1;i++)
			{
				if(vet[i]>vet[i+1])
				{
					aux=vet[i];
					vet[i]=vet[i+1];
					vet[i+1]=aux;
				}
			}
			tl2--;
    	}
    }

    public void exibe()
    {
        for(int i=0;i<tl;i++)
            System.out.print(vet[i]+" ");
    }
    public void heap()
    {
        int pai,f1,f2,maiorf,tl2=tl,aux;
        while(tl2>1)
        {
            for (pai = tl2/2-1;pai>-1;pai--)
            {
                f1 = pai+pai+1;
                f2=f1+1;
                maiorf = f1;
                if(f2<tl2 && vet[f2]>vet[f1])
                    maiorf=f2;
                if(vet[maiorf]>vet[pai])
                {
                     aux = vet[pai];
                     vet[pai] = vet[maiorf];
                     vet[maiorf] = aux;
                }
            }
            aux = vet[0];
            vet[0] = vet[tl2-1];
            vet[tl2-1] = aux;
            tl2--;
        }
    }

    public void quick_sempivo(int ini,int fim)
    {
        int aux,i=ini,j=fim;
        while(i<j)
        {
            while(i<j && vet[i]<=vet[j])
                i++;
            if(i<j)
            {
                aux=vet[j];
                vet[j]=vet[i];
                vet[i]=aux;
            }
            while(i<j && vet[j]>=vet[i])
                j--;
            if(i<j)
            {
                aux=vet[j];
                vet[j]=vet[i];
                vet[i]=aux;
            }
        }
        if(ini<i-1)
            quick_sempivo(ini,i-1);
        if(j+1<fim)
            quick_sempivo(j+1,fim);
    }

    public void quick_sempivoII(int ini,int fim)
    {
        int aux,i=ini,j=fim;
        boolean flag=true;
        while(i<j)
        {
            if(flag)
              while(i<j && vet[i]<=vet[j])
                 i++;
            else
              while(i<j && vet[j]>=vet[i])
                j--;
            if(i<j)
            {
                aux=vet[j];
                vet[j]=vet[i];
                vet[i]=aux;
            }
            flag=!flag;
        }
        if(ini<i-1)
            quick_sempivo(ini,i-1);
        if(j+1<fim)
            quick_sempivo(j+1,fim);
    }

    public void quick_compivo(int ini,int fim)
    {
        int pivo=(ini+fim)/2;
        int i=ini,j=fim,aux;
        while(i<j)
        {
            while(vet[i]<pivo)
                i++;
            while(vet[j]>pivo)
                j--;
            if(i<=j)
            {
                aux=vet[j];
                vet[j]=vet[i];
                vet[i]=aux;
                i++;
                j--;
            }
        }
        if(ini<j)
            quick_compivo(ini,j);
        if(i<fim)
            quick_compivo(i,fim);
    }

   public void shell()
   {
       int i=0,k,j,dist =4,aux;
       while(dist>=1)
       {
           for(i=0;i<dist;i++)
           {
               for(j=i;j<(tl-dist);j+=dist)
               {
                   if(vet[j] > vet[j+dist])
                   {
                         //troca
                         aux=vet[j+dist];
                         vet[j+dist]=vet[j];
                         vet[j]=aux;
                         k=j;
                         while (k-dist>=0 && vet[k]<vet[k-dist]) // volta
                         {
                             //troca
                             aux=vet[k];
                             vet[k]=vet[k-dist];
                             vet[k-dist]=aux;
                             k-=dist;
                         }
                   }
                   
               }
           }
           dist/=2;
     }
   }

   public void executa ()
     {
         le_vetor();
       //  insercao_direta();
         //shellSort();
         shell();
         exibe();
     }

}
