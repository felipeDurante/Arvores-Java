
package arquivo;

import java.io.IOException;
import java.io.RandomAccessFile;

public class Arquivo_Java {
private String nomearquivo;
  private RandomAccessFile arquivo;

  public Arquivo_Java(String nomearquivo)
  {
    this.nomearquivo = nomearquivo;
    try
    {
      arquivo = new RandomAccessFile(this.nomearquivo,"rw");
    }
    catch(IOException e){}
  }

  public void truncate(long pos) //desloca eof
  {
    try
    {
      arquivo.setLength(pos*Registro.length());
    }
    catch(IOException exc) { }
  }

  //igual ao eof do Pascal
  public boolean eof()      //se o ponteiro esta no eof
  {
    boolean retorno = false;
    try
    {
      if (arquivo.getFilePointer()==arquivo.length())  //retorna posicao em bytes
        retorno = true;                                //entao div por tam reg(52)
    }
    catch(IOException e){}
    finally
    {
      return(retorno);
    }
  }

  //insere um Registro no final do arquivo, passado por parâmetro
  public void inserirRegNoFinal(Registro reg)
  {
    try
    {
      arquivo.seek(arquivo.length());//ultimo byte
      reg.gravaNoArq(arquivo);
    }
    catch(IOException e){}
  }

  public void exibirArq()
  {/*registro reg = new registro();
    * seekarq(0);
    * while(!eof())
    * {
    * reg.ledoarq(arquivo);
    * reg.exibereg();
    * } melhor maneira de fazer esse metodo
    */
    int i;
    Registro aux = new Registro();
    try
    {
      arquivo.seek(0);
	  i=0;
	  while(!this.eof())
	  {
	     System.out.println("Posicao " + i);
		 aux.leDoArq(arquivo);
		 aux.exibirReg();
		 i++;
	  }
	}
	catch(IOException e){}
  }

  public void exibirUmRegistro(int pos)
  {
    Registro aux = new Registro();
    try
    {
      arquivo.seek(pos*Registro.length());
      System.out.println("Posicao " + pos);
      aux.leDoArq(arquivo);
	  aux.exibirReg();
	}
	catch(IOException e){}
  }

  public void seekArq(int pos)
  {
    try
    {
      arquivo.seek(pos*Registro.length());
	}
	catch(IOException e){}
  }

  public void leArq()
  {
    int codigo,idade;
    String nome;

    codigo=Entrada.leInteger("Digite o código");
    while (codigo!=0)
    {
      nome=Entrada.leString("Digite o nome");
      idade=Entrada.leInteger("Digite a idade");
      inserirRegNoFinal(new Registro(codigo,nome,idade));
      codigo=Entrada.leInteger("Digite o código");
    }
  }
  public void executa() throws IOException
  {
    leArq();
   // quick_sempivo(0,Filesize());
    //insercao_binaria();
    //heap();
    merge();
    exibirArq();
    System.out.println(Filesize());
  }
  public int Filesize() throws IOException
  {
      return (int) arquivo.length()/ Registro.length();
  }
  
  public void bolha_arquivo() throws IOException
  {
      int tl2= Filesize();
      Registro reg1= new Registro();
      Registro reg2= new Registro();
      while(tl2>1)
      {
          for(int i=0;i<tl2-1;i++)
          {
              seekArq(i);
              reg1.leDoArq(arquivo);
              reg2.leDoArq(arquivo);
              if(reg1.getCodigo()>reg2.getCodigo())
              {
                seekArq(i);
                reg2.gravaNoArq(arquivo);
                reg1.gravaNoArq(arquivo);
              }
          }
          tl2--;
      }
  }
  
  public void seleção_direta() throws IOException
  {
      int i,j,posmenor,tl=Filesize();
      Registro menor= new Registro();
      Registro reg1= new Registro();
      for(i=0;i<tl-1;i++)
      {
          seekArq(i);
          menor.leDoArq(arquivo);
          posmenor=i;
          for(j=i+1;j<tl;j++)
          {
              seekArq(j);
              reg1.leDoArq(arquivo);
              if(reg1.getCodigo()<menor.getCodigo())
              {
                 seekArq(j);
                 menor.leDoArq(arquivo);
                 posmenor=j;
              }
          }
          seekArq(i);
          reg1.leDoArq(arquivo);
          seekArq(posmenor);
          reg1.gravaNoArq(arquivo);
          seekArq(i);
          menor.gravaNoArq(arquivo);
      }
  }

  public void insercao_direta() throws IOException
  {
      Registro aux= new Registro();
      Registro aux2= new Registro();
      int pos,i;
      for(i=1;i<Filesize();i++)
      {
          pos=i;
          seekArq(pos);
          aux.leDoArq(arquivo);
          seekArq(pos-1);
          aux2.leDoArq(arquivo);
          while(pos>0 && aux2.getCodigo()>aux.getCodigo() )
          {
              seekArq(pos);
              aux2.gravaNoArq(arquivo);
              pos--;
          }
          seekArq(pos);
          aux.gravaNoArq(arquivo);
      }
  }

  public int busca_binaria(int aux,int i) throws IOException
  {
      Registro novo = new Registro();
      int meio,inicio,fim;
      inicio =0;
      fim= Filesize()-1;
      meio=fim/2;
      seekArq(meio);
      novo.leDoArq(arquivo);
      while(inicio<fim  && novo.getCodigo()!=aux )
      {
          if(novo.getCodigo()>aux)
              fim=meio;
          if(novo.getCodigo()<aux)
              inicio=meio+1;
          meio=(inicio+fim)/2;
          seekArq(meio);
          novo.leDoArq(arquivo);
      }
      seekArq(meio);
      novo.leDoArq(arquivo);
      if(novo.getCodigo()==aux)
         return meio;
      else if(aux>novo.getCodigo())
          return meio+1;
      
      return 0;
  }

  public void insercao_binaria() throws IOException
  {
      Registro aux= new Registro();
      Registro aux2= new Registro();
      int i,pos=0;
      for(i=0;i<Filesize();i++)
      {
          seekArq(i);
          aux2.leDoArq(arquivo);
          pos= busca_binaria(aux.getCodigo(),i);
          if(pos>i)
              pos-=i;
          for(int j=i;j>pos;j--)
          {
              seekArq(j);
              aux.leDoArq(arquivo);
              seekArq(j-1);
              aux.gravaNoArq(arquivo);
          }
          seekArq(pos);
          aux.gravaNoArq(arquivo);
      }
  }

  public int busca_exaustiva(int chave) throws IOException
  {
      int i=0;
      Registro aux = new Registro();
      seekArq(i);
      aux.leDoArq(arquivo);
      while(i<Filesize() && aux.getCodigo()!=chave)
      {
          i++;
          seekArq(i);
          aux.leDoArq(arquivo);
      }
      if (i<Filesize())
          return i;
      return 0;
  }

  public int busca_exaustiva_sentinela(int chave) throws IOException
  {
       Registro aux = new Registro();
       int i=0;
       seekArq(chave);
       aux.leDoArq(arquivo);
       seekArq(Filesize());
       aux.gravaNoArq(arquivo);
       seekArq(i);
       aux.leDoArq(arquivo);
       while(aux.getCodigo()!=chave)
       {
           i++;
           seekArq(i);
           aux.leDoArq(arquivo);
       }
       if (i<Filesize())
          return i;
      return 0;
  }

  public void heap () throws IOException
  {
      int pai,f1,f2,maior,tl=Filesize();
      Registro aux = new Registro();
      Registro aux1 = new Registro();
      while(tl>1)
      {
          for(pai=tl/2-1; pai>-1;pai--)
          {
              f1=pai+pai+1;
              f2=f1+2;
              maior=f1;
              if(f2<tl)
              {
                  seekArq(f2);
                  aux.leDoArq(arquivo);
                  if(aux.getCodigo()>maior)
                      maior=f2;
              }
              seekArq(maior);
              aux.leDoArq(arquivo);
              seekArq(pai);
              aux1.leDoArq(arquivo);
              if(aux.getCodigo()>aux1.getCodigo())
              {
                  seekArq(pai);
                  aux.gravaNoArq(arquivo);
                  seekArq(maior);
                  aux1.gravaNoArq(arquivo);
              }
          }
          seekArq(0);
          aux.leDoArq(arquivo);
          seekArq(tl-1);
          aux1.leDoArq(arquivo);
          seekArq(0);
          aux1.gravaNoArq(arquivo);
          seekArq(tl-1);
          aux.gravaNoArq(arquivo);

          tl--;
      }
  }

  public int busca_sequencial(int chave) throws IOException
  {
        int pos=0;
        Registro aux = new Registro();
        seekArq(pos);
        aux.leDoArq(arquivo);
        while(pos<Filesize() && aux.getCodigo()<chave)
        {
            pos++;
            seekArq(pos);
            aux.leDoArq(arquivo);
        }
        seekArq(pos);
        aux.leDoArq(arquivo);
        if(pos<Filesize() &&aux.getCodigo()==chave)
            return pos;
        else return pos+Filesize();
  }

public void quick_sempivo(int ini,int fim) throws IOException
    {
        int aux;
        int i=ini,j=fim;
        Registro reg= new Registro();
        Registro reg2= new Registro();
        while(i<j)
        {
            seekArq(j);
            reg2.leDoArq(arquivo);
            seekArq(i);
            reg.leDoArq(arquivo);
            while(i<j && reg.getCodigo()<=reg2.getCodigo())
            {
                i++;
                seekArq(i);
                reg.leDoArq(arquivo);
            }
            if(i<j)
            {
                seekArq(j);
                reg2.leDoArq(arquivo);
                seekArq(i);
                reg.leDoArq(arquivo);
                seekArq(j);
                reg.gravaNoArq(arquivo);
                seekArq(i);
                reg2.gravaNoArq(arquivo);
            }
            seekArq(j);
            reg2.leDoArq(arquivo);
            seekArq(i);
            reg.leDoArq(arquivo);
            while(i<j && reg2.getCodigo()>=reg.getCodigo())
            {
                j--;
                seekArq(j);
                reg2.leDoArq(arquivo);
            }
            if(i<j)
            {
                seekArq(j);
                reg2.leDoArq(arquivo);
                seekArq(i);
                reg.leDoArq(arquivo);
                seekArq(j);
                reg.gravaNoArq(arquivo);
                seekArq(i);
                reg2.gravaNoArq(arquivo);
            }
        }
        if(0<i-1)
            quick_sempivo(0,i-1);
        if(j+1<fim)
            quick_sempivo(j+1,fim);
    }

    public void shell() throws IOException
    {
       int i=0,k,j,dist= 4,tl= Filesize();
       Registro aux= new Registro();
       Registro aux2= new Registro();
       while(dist>0)
       {
           while(i<dist)
           {
               j=i;
               while (j+dist<tl)
               {
                   seekArq(j);
                   aux.leDoArq(arquivo);
                   seekArq(j+1);
                   aux2.leDoArq(arquivo);
                   if(aux.getCodigo() > aux2.getCodigo())
                   {
                         //troca
                         seekArq(j);
                         aux.leDoArq(arquivo);
                         seekArq(j+1);
                         aux2.leDoArq(arquivo);
                         seekArq(j);
                         aux2.gravaNoArq(arquivo);
                         seekArq(j+1);
                         aux.gravaNoArq(arquivo);
                         k=j;
                         seekArq(k);
                         aux.leDoArq(arquivo);
                         seekArq(k-dist);
                         aux2.leDoArq(arquivo);
                         while (k-dist>=0 && aux.getCodigo()<aux2.getCodigo()) // volta
                         {
                             //troca
                             seekArq(k);
                             aux.leDoArq(arquivo);
                             seekArq(k-dist);

                                     aux2.leDoArq(arquivo);
                             seekArq(k);
                             aux2.gravaNoArq(arquivo);
                             seekArq(k-dist);
                             aux.gravaNoArq(arquivo);
                             k-=dist;
                             seekArq(k);
                             aux.leDoArq(arquivo);
                             seekArq(k-dist);
                             aux2.leDoArq(arquivo);
                         }
                   }
                   j+=dist;
               }
               i++;
           }
           dist/=2;
     }
   }

    void shake ()throws IOException
   {
       int fim=Filesize()-1, inicio=0;
       Registro aux= new Registro();
       Registro aux2= new Registro();

       while(inicio < fim)
       {
           for(int i=inicio;i<fim;i++)
           {
               seekArq(i);
               aux.leDoArq(arquivo);
               seekArq(i+1);
               aux2.leDoArq(arquivo);
               if (aux.getCodigo()>aux2.getCodigo())
               {
                   seekArq(i);
                   aux.leDoArq(arquivo);
                   seekArq(i+1);
                   aux2.leDoArq(arquivo);
                   seekArq(i);
                   aux2.gravaNoArq(arquivo);
                   seekArq(i+1);
                   aux.gravaNoArq(arquivo);
               }
           }
           fim--;
           for (int i=fim;i>inicio;i--)
           {
               seekArq(i);
               aux.leDoArq(arquivo);
               seekArq(i-1);
               aux2.leDoArq(arquivo);
               if (aux.getCodigo()<aux2.getCodigo())
               {
                   seekArq(i);
                   aux.leDoArq(arquivo);
                   seekArq(i-1);
                   aux2.leDoArq(arquivo);
                   seekArq(i);
                   aux2.gravaNoArq(arquivo);
                   seekArq(i-1);
                   aux.gravaNoArq(arquivo);
               }
           }
           inicio++;
       }
   }

    public void fusao (int seq,RandomAccessFile a1,RandomAccessFile a2) throws IOException
   {
       int i,j,k;
       i=j=k=0;
       int tseq = seq;
       Registro aux = new Registro();
       Registro aux2 = new Registro();
      while(i<seq && j<seq)
      {
           a1.seek(i*Registro.length());
           aux.leDoArq(a1);
           a2.seek(j*Registro.length());
           aux2.leDoArq(a2);
           if(aux.getCodigo()<aux2.getCodigo())
             {
                seekArq(k);
                aux.gravaNoArq(arquivo);
                i++;
                k++;
             }
             else
             {
                seekArq(k);
                aux2.gravaNoArq(arquivo);
                j++;
                k++;
             }
       }
       a1.seek(i*Registro.length());
       aux.leDoArq(a1);
       a2.seek(j*Registro.length());
       aux2.leDoArq(a2);
       while(i<seq)
       {
          seekArq(k);
          aux.gravaNoArq(arquivo);
          i++;
          k++;
          a1.seek(i*Registro.length());
          aux.leDoArq(a1);
       }
       while(j<seq)
       {
          seekArq(k);
          aux.gravaNoArq(arquivo);
          j++;
          k++;
          a2.seek(j*Registro.length());
          aux2.leDoArq(a2);
       }
       seq+=tseq;
   }


   public void particao (RandomAccessFile a1,RandomAccessFile a2,int tam) throws IOException
   {
       Registro aux = new Registro();
       int k=0;
       for(int i=0;i<tam;i++)
       {
           seekArq(i);
           aux.leDoArq(arquivo);
           a1.seek(k*Registro.length());
           aux.gravaNoArq(a1);
           seekArq(i+tam);
           aux.leDoArq(arquivo);
           a2.seek(k*Registro.length());
           aux.gravaNoArq(a2);
           k++;
       }
   }


   public void merge () throws IOException
   {
       RandomAccessFile a1=new RandomAccessFile("f:\\arqaux1.dat","rw");
       RandomAccessFile a2=new RandomAccessFile("f:\\arqaux2.dat","rw");;
       int seq=1,tl=Filesize();
       while (seq<tl)
       {
           particao(a1,a2,tl/2);
           fusao(seq,a1,a2);
           seq*=2;
       }
   }
}
