
package arquivo;

import java.io.IOException;

public class Main {

   public static void main(String args[]) throws IOException
  {
      Arquivo_Java a = new Arquivo_Java("f:\\arq.dat");
      

      a.executa();
  }

}
