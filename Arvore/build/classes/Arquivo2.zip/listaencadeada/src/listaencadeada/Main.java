
package listaencadeada;

public class Main {

    public static void main(String[] args) 
    {
    //   InsereLista_noFinal(8);
       
    }

}
