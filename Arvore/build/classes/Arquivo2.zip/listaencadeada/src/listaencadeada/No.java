

package listaencadeada;

public class No
{
    private No ant,prox;
    private int info;

    public No(No ant, No prox,int info)
    {
        this.ant= ant;
        this.info= info;
        this.prox= prox;
    }

    public No getAnt() {
        return ant;
    }

    public int getInfo() {
        return info;
    }

    public No getProx() {
        return prox;
    }

    public void setAnt(No ant) {
        this.ant = ant;
    }

    public void setInfo(int info) {
        this.info = info;
    }

    public void setProx(No prox) {
        this.prox = prox;
    }


}
