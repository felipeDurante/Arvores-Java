

package listaencadeada;

public class Lista
{
    private No inicio;
    private No fim;

    public Lista ()
    {
        Inicializa();
    }

    public void Inicializa()
    {
        inicio=fim=null;
    }

    public void InsereLista_noFinal(int info)
    {
        No nova = new No(fim,null,info);
        if(inicio==null)
            inicio=fim= nova;
        else
        {
            fim.setProx(nova);
            fim= nova;
        }
    }

    public void InsereLista_tipoPilha(int info)
    {
        No nova = new No(null,inicio,info);
        if(inicio==null)
            inicio=fim=nova;
        else
        {
            inicio.setAnt(nova);
            inicio=nova;
        }
    }

    public void Exibe_Lista()
    {
        No aux = inicio;
        while(aux!=null)
        {
            System.out.println(aux.getInfo());
            aux= aux.getProx();
        }
    }

    public No Busca_Exaustiva(int Elem)
    {
        No aux = inicio;
        while(aux!=null && aux.getInfo()!=Elem)
            aux = aux.getProx();
        return aux;
    }

   public No busca_exaustiva_sentinela (int chave)
    {
	No aux = inicio;
        InsereLista_noFinal(chave);
	while(aux.getInfo()!=chave)
            aux = aux.getProx();
        if(aux.getProx()==null)
        {
            aux.getAnt().setProx(null);
            return null;
        }
        No aux2 = aux;
        while(aux2.getProx()!=null)
            aux2=aux2.getProx();
        aux2.getAnt().setProx(null);
        return aux;
     }

   public void bolha_lista()
   {
       No fim2=fim,i;
       int aux;
       while(fim2!=inicio)
       {
           i=inicio;
           while(i!=fim2)
           {
               if(i.getInfo()>i.getProx().getInfo())
               {
                   aux=i.getInfo();
                   i.setInfo((i.getProx().getInfo()));
                   i.getProx().setInfo(aux);
               }
               i=i.getProx();
           }
           fim2=fim2.getAnt();
       }
   }
   
   public void insercao_direta()
    {
        No pos= inicio,i=inicio;
        int aux;
        while(i!=fim)
        {
            aux=i.getInfo();
            pos=i;
            while(pos!=inicio && i.getAnt().getInfo()>aux)
            {
                pos.setInfo(pos.getAnt().getInfo());
                pos=pos.getAnt();
            }
            pos.setInfo(aux);
        }
    }

   public No busca_sequencial(int chave)
   {
       No pos=inicio,i=inicio;
       while(pos!=fim && pos.getInfo()<chave)
           pos=pos.getProx();
       if(pos!=fim && pos.getInfo()==chave)
           return pos;
       return fim;

   }





 /*  public No busca_binaria (int chave)
    {
        int inicio,fim,meio;
        inicio =0;
        fim = tl-1;
        meio = fim/2;
        while(inicio<fim && vet[meio]!=chave)
        {
            if(vet[meio]>chave)
                fim=meio;
            if (vet[meio]<chave)
                inicio=meio+1;
            meio=(inicio+fim)/2;
        }
        if(vet[meio]==chave)
            return meio;
        else if(chave>vet[meio])
        return meio+1;
    }    
*/
// heap
	public void Selecao_direta()
	{	
		No pos=inicio,aux2,aux=inicio;
		int menor;
		while(aux!=fim)
		{
			aux2= aux.getProx();
			menor= aux.getInfo();
			while(aux2!=fim)
			{
				if(aux2.getInfo()<menor)
				{
					menor=aux2.getInfo();
					pos= aux2;
				}
				aux2=aux2.getProx();
			}
			pos.setInfo(aux.getInfo());
			aux.setInfo(menor);
			aux= aux.getProx();
		}
	}

    public void RemoveLista(int info)
    {
         No aux = Busca_Exaustiva(info);
         if(aux!=null)
         {
             if(inicio==fim)
                 Inicializa();
             else if(inicio==aux)
             {
                 inicio = inicio.getProx();
                 inicio.setAnt(null);
             }
             else if(fim==aux)
             {
                 fim = fim.getAnt();
                 fim.setProx(null);
             }
             else
             {
                 aux.getAnt().setProx(aux.getProx());
                 aux.getProx().setAnt(aux.getAnt());
             }
         }
    }

    public void quick_sempivo(No ini,No fim)
    {
        No i=ini,j=fim;
        int aux;
        while(i!=j)
        {
            while(i!=j && i.getInfo()<=j.getInfo())
                i=i.getProx();
            if(i.getInfo()>j.getInfo())
            {
                aux=j.getInfo();
                j.setInfo(i.getInfo());
                i.setInfo(aux);
            }
            while(i!=j && j.getInfo()>=i.getInfo())
                j=j.getAnt();
            if(j.getInfo()<i.getInfo())
            {
                aux=j.getInfo();
                j.setInfo(i.getInfo());
                i.setInfo(aux);
            }
        }
        if(ini!=i.getAnt())
            quick_sempivo(ini,i.getAnt());
        if(j.getProx()!=fim)
            quick_sempivo(j.getProx(),fim);
    }

   /* public void Heap()
    {
        No aux;

    }*/

}
